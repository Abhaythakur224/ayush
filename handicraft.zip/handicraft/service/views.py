from django.shortcuts import render ,redirect ,get_object_or_404 ,HttpResponse
from service.models import product, Contact, order
from django.contrib import messages
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth import  login as lap
from django.contrib.auth import logout as djnago_logouts
from django.contrib.auth.models import User
from datetime import datetime
# from django.contrib.auth.decorators import login_required

# Create your views here.

def login(request):
    if request.method == "POST":
        # Get the post parameters
        username = request.POST['username']
        email = request.POST['email']
        phone = request.POST['phone']
        password = request.POST['password']

        # check for errorneous input

        try:
            user = User.objects.get(username=username)
            messages.warning(request, " Username Already taken. Try with different Username.")
            return redirect('login')
        except User.DoesNotExist:
            # Create the user
            myuser = User.objects.create_user(username=username, email=email, password=password)
            myuser.first_name = phone
            # myuser.last_name = l_name
            myuser.phone = phone
            
            myuser.save()
            messages.success(request, " Your Account has been successfully created " + username)
            return redirect('index')
    else:
        return render(request, 'login.html')




def visiting(request):
    servicedata = product.objects.filter(Categry__contains='visiting card')#yahi method hame databse se data get karke deta hai
    data={
        'servicedata':servicedata,
    }
    return render(request, 'visiting.html',data)

def printproducts(request):
    servicedata = product.objects.filter(Categry__contains='printing products')#yahi method hame databse se data get karke deta hai
    data={
        'servicedata':servicedata,
    }
    return render(request, 'printproducts.html',data)

def index(request):
    servicedata = product.objects.all()#yahi method hame databse se data get karke deta hai
    topbannerdata = product.objects.all()#yahi method hame databse se data get karke deta hai
    slidedata = product.objects.all()[:6]
    if request.method=="GET":   
        st=request.GET.get("servicename")
        if st!=None:
            servicedata = product.objects.filter(Service_title__icontains=st)
    data={
        'servicedata':servicedata,
        'slidedata':slidedata,
        'topbannerdata':topbannerdata
    }
    return render(request, 'index.html',data)

def search(request):
    servicedata = product.objects.all()#yahi method hame databse se data get karke deta hai
    if request.method=="GET":   
        st=request.GET.get("servicename")
        if st!=None:
            servicedata = product.objects.filter(Service_title__icontains=st)
    data={
        'servicedata':servicedata,
    }
    return render(request, 'search.html',data)

@login_required(login_url='login')
def user(request):
    return render(request, 'user.html')

def ordertrace(request):
    return render(request, 'ordertrace.html')

def about(request):
    return render(request, 'about.html')

def base(request):
    Contact = User.objects.all()#yahi method hame databse se data get karke deta hai
    data={
        'Contact':Contact,
    }
    return render(request, 'base.html',data)
    
def howorder(request):
    Contact = User.objects.all()
    data={
        'Contact':Contact,
    }
    return render(request, 'howorder.html',data)

@login_required(login_url='login')
def allen(request):
    if request.method == "POST":
        product_id = request.POST.get('product_id')
        Product = request.POST.get('Product')
        contact = request.POST.get('contact')
        Orientation = request.POST.get('Orientation')
        printface = request.POST.get('printface')
        Pincode = request.POST.get('Pincode')
        myfile = request.POST.get('myfile')
        quantity =request.POST.get('quantity')
        addinfo = request.POST.get('addinfo')
        id = order.product_id
        if len(Pincode) != 6:
            messages.error(request, 'your pin code is incorrect!')
            return redirect('/')
        if order.objects.filter(contact=contact):
            messages.error(request, 'This Contact   number is alredy exist!')
            return render(request, '/')
        else:
            content = order(Product=Product,contact=contact,printface=printface,Orientation=Orientation,Pincode=Pincode,myfile=myfile,quantity=quantity ,addinfo=addinfo ,)
            content.save()
        messages.success(request, 'Congratulation   your order has been placed',{'id':id})
        return redirect('/')

def contact(request):
    thank = False
    if request.method == "POST":
        uname = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        msg = request.POST.get('msg', '')
        contact = Contact(uname=uname, email=email, phone=phone, msg=msg)
        contact.save()
        thank = True
        return render(request, 'contact.html', {'thank': thank})
    return render(request, 'contact.html', {'thank': thank})




def singin(request):
    if request.method == 'POST':
        username = request.POST['username']
        pass1 = request.POST['pass1']

        user = authenticate(username=username, password=pass1)
        if user is not None:
            lap(request, user)
            messages.success(request, "Welcome back! "+ username)
            return redirect('/')
        else:
            messages.error(request, "Check your Crdentials!!")
            return redirect('login')
    
    return render(request, "login.html")

def logout(request):
    djnago_logouts(request)
    messages.success(request, 'you are logout successfully!')
    return redirect('/')
def checkout(request):

    return render(request, 'checkout.html')


def quicrew(request,myid):   
        slidedata = product.objects.all()[:6]#yahi method hame databse se data get karke deta hai
        prodetail=product.objects.get(id=myid)
        # quicslide = product.objects.filter('Service_title')
        data={  
                'prodetail':prodetail,
                # 'quicslide':quicslide,
                'slidedata':slidedata
        }   
        print(data) 
        return render(request, 'quicrew.html',data)


