from django.contrib import admin
from service.models import product , Contact ,order
# Register your models here.
class ServiceAdmin(admin.ModelAdmin):
    list_display=('product_price','Categry','Service_title','Service_desc','Servicemore_desc','Service_img','Service2_img','Service3_img')

admin.site.register(product,ServiceAdmin)
admin.site.register(Contact)
admin.site.register(order)

admin.site.site_header = "The Handicrafters.."
admin.site.index_title = "The Handicrafters.. Administration"
admin.site.site_title = "The Handicrafters.. Admin"
