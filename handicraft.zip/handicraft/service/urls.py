from django.contrib import admin
from django.urls import path
from service import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('user', views.user, name='user'),
    path('', views.index,  name='index'),
    path('login', views.login,  name='login'),
    path('checkout', views.checkout,  name='checkout'),
    path('singin', views.singin,  name='singin'),
    path('quicrew<int:myid>', views.quicrew,  name='quicrew'),
    path('ordertrace', views.ordertrace,  name='ordertrace'),
    path('about', views.about,  name='about'),
    path('allen', views.allen,  name='allen'),
    path('visiting', views.visiting,  name='visiting'),
    path('printproducts', views.printproducts,  name='printproducts'),
    path('contact', views.contact,  name='contact'),
    path('howorder', views.howorder,  name='howorder'),
    path('logout', views.logout,  name='logout'),
    path('search', views.search,  name='search'),
    path('base', views.base,  name='base'),
]


if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)