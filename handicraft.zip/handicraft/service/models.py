from django.db import models
from django.utils import timezone

# Create your models here.

class product(models.Model):
    Service_title=models.CharField(max_length=50)
    Categry=models.CharField(max_length=50,default="")
    product_price=models.CharField(max_length=50)
    Service_img=models.FileField(upload_to="mmedia/",max_length=250 , null=True,default=None) 
    Service2_img=models.FileField(upload_to="mmedia/",max_length=250 , null=True,default=None) 
    Service3_img=models.FileField(upload_to="mmedia/",max_length=250 , null=True,default=None) 
    Service_desc=models.TextField()
    Servicemore_desc=models.TextField(null=True,default="")

class Contact(models.Model):
    uname=models.CharField(max_length=50)
    email=models.EmailField(max_length=254)
    phone=models.CharField(max_length=10,null=True)
    msg=models.CharField(max_length=100 ,null=False,default="")
    timestamp = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.email

class order(models.Model):
    product_id = models.AutoField(primary_key=True)
    Product=models.CharField(max_length=66,null="True")
    contact=models.CharField(max_length=50)
    Orientation=models.EmailField(max_length=254)
    printface=models.EmailField(max_length=254)
    quantity=models.CharField(max_length=50)
    Pincode=models.CharField(max_length=50)
    myfile=models.ImageField(upload_to=None, height_field=None, null=True, width_field=None, max_length=None)
    addinfo=models.TextField(max_length=50)
    timestamp = models.DateTimeField(default=timezone.now)
